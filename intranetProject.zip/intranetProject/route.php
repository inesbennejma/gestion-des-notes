<?php
$sp=$_GET['specialite'];
$niv=$_GET['niveau'];


  $servername="localhost";
  $username="root";
  $password="";
  $dbname="intranet";

  $conn=mysqli_connect($servername,$username,$password,$dbname);
if ($niv==3) {
  header("location:ajouter_note2.php?specialite=".$sp."&niveau=".$niv);
} else if($niv==5){
	header("location:ajouter_note20.php?specialite=".$sp."&niveau=".$niv);
} else if ($niv==4){
	header("location:ajouter_note12.php?specialite=".$sp."&niveau=".$niv);
}
else if ($niv==1) {
	header("location:ajouter_note10.php?specialite=".$sp."&niveau=".$niv);
}
else{
  header("location:ajouter_note1.php?specialite=".$sp."&niveau=".$niv);
}




?>