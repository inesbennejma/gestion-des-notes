<div class="card mb-4 bg-dark text-white" style="height: 220px; margin-right: 12%; margin-left: 12%; margin-top: 20px; border-radius: 10px; box-shadow: 100px;">
            <img class="card-img" src="images/Student-final.png" alt="Card image" style="height: 219px; background: black; opacity: 0.7; border-radius: 10px; box-shadow: 100px;">
            <div class="card-img-overlay1" style="height: 60%; top: none !important; padding: none !important;">
               <h3><center> Relever De Notes </center></h3>
            </div>
          </div>


          <div class="card mb-4 bg-dark text-white" style="height: 220px; margin-right: 12%; margin-left: 12%; margin-top: 20px; border-radius: 10px;">
            <img class="card-img" src="images/stage.jpg" alt="Card image" style="height: 219px; background: black; opacity: 0.7; border-radius: 10px;">
            <div class="card-img-overlay1" style="height: 60%; top: none !important; padding: none !important;">
               <h3><center> Resultat De Stage </center></h3>
            </div>
          </div>



          <div class="card mb-4 bg-dark text-white" style="height: 220px; margin-right: 12%; margin-left: 12%; margin-top: 20px; border-radius: 10px;">
            <img class="card-img" src="images/stage1.jpg" alt="Card image" style="height: 219px; background: black; opacity: 0.7; border-radius: 10px;">
            <div class="card-img-overlay1" style="height: 60%; top: none !important; padding: none !important;">
               <h3><center> Attestation De Stage </center></h3>
            </div>
          </div>